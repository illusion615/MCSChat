import { Chat } from './components/Chat';

export default function App() {
  return (
    <div className="h-screen w-full">
      <Chat />
    </div>
  );
}