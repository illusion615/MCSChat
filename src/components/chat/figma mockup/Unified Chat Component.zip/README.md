
  # Unified Chat Component

  This is a code bundle for Unified Chat Component. The original project is available at https://www.figma.com/design/VJW3TlBhT4c2g6UApwCwyi/Unified-Chat-Component.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  